// js/views/main_view_profile.js
import { esc } from '../core/utils.js';

export function renderProfileBox(right, state, DB, render) {
  // Extract username from URL or return as-is if already a username
  function getSocialUsername(val, type) {
    if (!val) return '';
    let v = val.trim();
    if (!v) return '';
    if (type === 'youtube') {
      // If it's a full YouTube video or shorts URL, return as-is
      if (/^https?:\/\/(www\.)?youtube\.com\/(watch\?v=|shorts\/)[^\s]+/i.test(v)) {
        return v;
      }
      // Remove protocol and www for username/handle extraction
      v = v.replace(/^https?:\/\//i, '').replace(/^www\./i, '');
      v = v.replace(/^youtube\.com\//i, '');
      v = v.replace(/^@/, '').replace(/\/$/, '');
      return v ? '@' + v : '';
    }
    // Remove protocol
    v = v.replace(/^https?:\/\//i, '');
    switch (type) {
      case 'facebook':
        v = v.replace(/^(www\.)?facebook\.com\//i, '');
        break;
      case 'instagram':
        v = v.replace(/^(www\.)?instagram\.com\//i, '');
        break;
      case 'twitter':
        v = v.replace(/^(www\.)?twitter\.com\//i, '');
        break;
      case 'bandcamp':
        v = v.replace(/^(www\.)?([^\.]+)\.bandcamp\.com.*/i, '$2');
        break;
      case 'soundcloud':
        v = v.replace(/^(www\.)?soundcloud\.com\//i, '');
        break;
      default:
        break;
    }
    // Remove trailing slashes and @, then add @ for display
    v = v.replace(/^@/, '').replace(/\/$/, '');
    return v ? '@' + v : '';
  }
  const db = DB.getAll();
  const me = state.user;
  if (!me) return;

  const meUser = db.users.find(u => u.id === me.id) || null;
  const myAbout = meUser?.about || '';
  const myAvatar = meUser?.avatarUrl || '/assets/android-chrome-512x512.png';
  const socials = {
    facebook: meUser?.facebook || '',
    instagram: meUser?.instagram || '',
    twitter: meUser?.twitter || '',
    bandcamp: meUser?.bandcamp || '',
    soundcloud: meUser?.soundcloud || '',
    youtube: meUser?.youtube || ''
  };

  function renderSocialLinks(s) {
    const icons = { facebook: '🌐', instagram: '📸', twitter: '🐦', bandcamp: '🎵', soundcloud: '☁️', youtube: '▶️' };
    return Object.entries(s)
      .filter(([_, v]) => v)
      .map(([k, v]) => `<a href="${esc(v)}" target="_blank" rel="noopener" class="social-link" title="${k}">${icons[k]}</a>`)
      .join(' ');
  }

  const box = document.createElement('div');
  box.className = 'box';
  box.id = 'aboutBox';
  box.innerHTML = `
    <div class="muted small">&gt; my profile</div>
    <div style="display:flex; flex-direction:column; align-items:center; margin-bottom:8px;">
      <img class="profile-avatar-small" src="${esc(myAvatar)}" alt="avatar" />
    </div>
    <div id="aboutCollapsed" style="display:flex; flex-direction:column; gap:8px; min-height:38px;">
      <div id="aboutText" class="about-preview">${
        myAbout ? esc(myAbout).replace(/\n/g, '<br>') : '<span class="muted small">no about yet.</span>'
      }</div>
      <div id="aboutSocials">${renderSocialLinks(socials) || '<span class="muted small">no social links</span>'}</div>
      <button class="btn btn-ghost small" id="editAboutBtn" type="button">[ edit ]</button>
    </div>
    <form class="stack" id="aboutEditForm" data-action="profile-form" autocomplete="off" style="display:none; margin-top:8px;" enctype="multipart/form-data">
  <label class="muted small" style="margin-bottom:4px;" for="avatarFile">Change avatar:</label>
      <div class="custom-file-input-wrapper" style="margin-bottom:8px;">
        <input class="custom-file-input" type="file" id="avatarFile" name="avatar" accept="image/*" />
        <label for="avatarFile" class="btn btn-ghost small" id="avatarFileLabel">[ upload new avatar ]</label>
        <span class="muted small" id="avatarFileName" style="margin-left:8px;"></span>
      </div>
      <textarea class="field" id="aboutMe" name="about" rows="3" maxlength="500" placeholder="Write a short bio...">${esc(myAbout)}</textarea>
      <fieldset class="social-links-group" style="border:1px dashed var(--line); border-radius:8px; padding:12px; margin:12px 0;">
        <legend class="muted small" style="padding:0 8px;">Social Links</legend>
        <div class="social-fields" style="display:grid; grid-template-columns:1fr; gap:8px;">
          <label for="socialFb"><span class="sr-only">Facebook</span></label>
          <input class="field" type="text" id="socialFb" name="fb_user" placeholder="Facebook username or URL" value="${esc(getSocialUsername(socials.facebook, 'facebook'))}" autocomplete="username" />
          <label for="socialInsta"><span class="sr-only">Instagram</span></label>
          <input class="field" type="text" id="socialInsta" name="insta_user" placeholder="Instagram username or URL" value="${esc(getSocialUsername(socials.instagram, 'instagram'))}" autocomplete="username" />
          <label for="socialTwtr"><span class="sr-only">Twitter</span></label>
          <input class="field" type="text" id="socialTwtr" name="twtr_user" placeholder="Twitter username or URL" value="${esc(getSocialUsername(socials.twitter, 'twitter'))}" autocomplete="username" />
          <label for="socialBandcamp"><span class="sr-only">Bandcamp</span></label>
          <input class="field" type="text" id="socialBandcamp" name="bc_user" placeholder="Bandcamp username or URL" value="${esc(getSocialUsername(socials.bandcamp, 'bandcamp'))}" autocomplete="username" />
          <label for="socialSoundcloud"><span class="sr-only">SoundCloud</span></label>
          <input class="field" type="text" id="socialSoundcloud" name="sc_user" placeholder="SoundCloud username or URL" value="${esc(getSocialUsername(socials.soundcloud, 'soundcloud'))}" autocomplete="username" />
          <label for="socialYoutube"><span class="sr-only">YouTube</span></label>
          <input class="field" type="text" id="socialYoutube" name="yt_user" placeholder="YouTube username or URL" value="${esc(getSocialUsername(socials.youtube, 'youtube'))}" autocomplete="username" />
        </div>
        <div class="muted small" style="margin-top:8px;">You can enter just your username or a full URL for each social field.</div>
      </fieldset>
      <div class="hstack">
        <button class="btn" type="submit">[ save about ]</button>
        <button class="btn btn-ghost small" id="cancelAboutBtn" type="button">[ cancel ]</button>
        <span class="muted small" id="profileMsg"></span>
      </div>
    </form>
  `;

  // Custom file input JS: show file name, hide default text
  const avatarFileInput = box.querySelector('#avatarFile');
  const avatarFileName = box.querySelector('#avatarFileName');
  if (avatarFileInput && avatarFileName) {
    avatarFileInput.addEventListener('change', function() {
      avatarFileName.textContent = this.files && this.files.length > 0 ? this.files[0].name : '';
    });
  }
  right.appendChild(box);

  const aboutCollapsed = box.querySelector('#aboutCollapsed');
  const aboutEditForm = box.querySelector('#aboutEditForm');
  const editBtn = box.querySelector('#editAboutBtn');
  const cancelBtn = box.querySelector('#cancelAboutBtn');

  // Animate out the collapsed section, then show the edit form
  editBtn.addEventListener('click', () => {
    aboutCollapsed.classList.add('fade-out');
    aboutCollapsed.classList.remove('fade-in');
    setTimeout(() => {
      aboutCollapsed.style.display = 'none';
      aboutEditForm.style.display = '';
      // Prevent auto-focus on mobile devices (avoid keyboard pop-up)
      if (!/Mobi|Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent)) {
        aboutEditForm.querySelector('#aboutMe').focus();
      }
    }, 180); // match CSS duration
  });
  // Animate in the collapsed section when canceling
  cancelBtn.addEventListener('click', () => {
    aboutEditForm.style.display = 'none';
    aboutCollapsed.style.display = 'flex';
    aboutCollapsed.classList.remove('fade-out');
    aboutCollapsed.classList.add('fade-in');
  });

  function formatSocial(val, type) {
    const input = (val || '').trim();
    if (!input) return '';
    // If input is a full URL, return as-is
    if (/^https?:\/\//i.test(input)) return input;
    switch (type) {
      case 'facebook':
        return 'https://facebook.com/' + input.replace(/^@/, '');
      case 'instagram':
        return 'https://instagram.com/' + input.replace(/^@/, '');
      case 'twitter':
        return 'https://twitter.com/' + input.replace(/^@/, '');
      case 'bandcamp':
        return 'https://' + input.replace(/^https?:\/\//, '').replace(/\/$/, '') + '.bandcamp.com/';
      case 'soundcloud':
        return 'https://soundcloud.com/' + input.replace(/^@/, '');
      case 'youtube':
        // If input looks like a YouTube video ID, build a watch URL
        if (/^[\w-]{11}$/.test(input)) {
          return 'https://www.youtube.com/watch?v=' + input;
        }
        // If input looks like a handle (starts with @), build a channel URL
        if (/^@/.test(input)) {
          return 'https://www.youtube.com/' + input;
        }
        // Otherwise, assume it's a username or channel name
        return 'https://www.youtube.com/c/' + input.replace(/^@/, '');
      default:
        return input;
    }
  }

  aboutEditForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const form = aboutEditForm;

  const about = form.querySelector('#aboutMe').value;
  const facebook = formatSocial(form.querySelector('#socialFb').value, 'facebook');
  const instagram = formatSocial(form.querySelector('#socialInsta').value, 'instagram');
  const twitter = formatSocial(form.querySelector('#socialTwtr').value, 'twitter');
  const bandcamp = formatSocial(form.querySelector('#socialBandcamp').value, 'bandcamp');
  const soundcloud = formatSocial(form.querySelector('#socialSoundcloud').value, 'soundcloud');
  const youtube = formatSocial(form.querySelector('#socialYoutube').value, 'youtube');

  await DB.updateUser(me.id, { about, facebook, instagram, twitter, bandcamp, soundcloud, youtube });
    setTimeout(() => {
      aboutEditForm.style.display = 'none';
      aboutCollapsed.style.display = 'flex';
      aboutCollapsed.classList.remove('fade-out');
      aboutCollapsed.classList.add('fade-in');
      if (typeof render === 'function') render();
    }, 100);
  });
}