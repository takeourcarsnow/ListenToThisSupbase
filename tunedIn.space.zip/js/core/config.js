// Toggle remote vs local storage
export const USE_SUPABASE = true;

// Put your Supabase project creds here (these are safe to be public; enforce RLS).
export const SUPABASE_URL = 'https://ykwbnqaobcirrpunnkkn.supabase.co';
export const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inlrd2JucWFvYmNpcnJwdW5ua2tuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTU2MDcwMjcsImV4cCI6MjA3MTE4MzAyN30.qoZg10-v6rmqW6RZDj9SGYio_DblzSfP3RTPBMoJBuM';